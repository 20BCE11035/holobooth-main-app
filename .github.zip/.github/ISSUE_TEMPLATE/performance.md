---
name: Performance Update
about: A code change that improves performance
title: 'perf: '
labels: performance
---

**Description**

Clearly describe what code needs to be changed and what the performance impact is going to be. Bonus point's if you can tie this directly to user experience.

**Requirements**

- [ ] There is no drop in the unit or widget test coverage percentage.