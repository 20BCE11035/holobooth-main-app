---
name: Documentation
about: Improve the documentation so all collaborators have a common understanding
title: 'docs: '
labels: documentation
---

**Description**

Clearly describe what documentation you are looking to add or improve.

**Requirements**

- [ ] Checklist of requirements to be fulfilled
