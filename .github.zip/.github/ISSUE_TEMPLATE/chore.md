---
name: Chore
about: Other changes that don't modify src or test files
title: 'chore: '
labels: chore
---

**Description**

Clearly describe what change is needed and why. If this changes code then please use another issue type.

**Requirements**

- [ ] No functional changes to the code